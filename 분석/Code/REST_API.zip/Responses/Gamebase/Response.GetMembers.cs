﻿namespace BBF.REST_API.Response.Gamebase
{
    public class Get_Members : Response_GameBase
    {
        public MemberList[] memberList;
    }
}