﻿namespace BBF.REST_API.Response.Gamebase
{
    public class Get_IDP_Information : Response_GameBase
    {
        public Result[] result;
    }
}