﻿namespace BBF.REST_API.Response.Gamebase
{
    public class Get_UserId_Information_with_Auth_key : Response_GameBase
    {
        public string[] result;
    }
}
