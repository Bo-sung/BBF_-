﻿namespace BBF.REST_API.Response.Gamebase
{
    public class Get_Member : Response_GameBase
    {
        public Member member;

        public TemporaryWithdrawal temporaryWithdrawal;

        public MemberInfo memberInfo;
    }
}