﻿namespace BBF.REST_API.Response.Gamebase
{
    public class Get_IdP_Token_and_Profiles : Response_GameBase
    {
        public IdpProfile idPProfile;

        public IdpToken idPToken;
    }
}