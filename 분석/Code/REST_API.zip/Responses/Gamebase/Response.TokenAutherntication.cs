﻿namespace BBF.REST_API.Response.Gamebase
{
    public class TokenAuthentication : Response_GameBase
    {
        public LinkedIdP linkedIdP;
    }
}