﻿namespace BBF.REST_API.Response
{
    public class Response_Base
    {
        //이 클래스 상속받아 Response 데이터 처리할것!!.
    }
}

