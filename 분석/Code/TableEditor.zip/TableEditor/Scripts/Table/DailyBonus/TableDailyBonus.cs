﻿using System.Collections;
using System.Collections.Generic;


public class TableDailyBonus
{
    public int index;
    public int reward_count;
}