﻿using System.Collections;
using System.Collections.Generic;


public class TableClearReward
{
    public int index;
    public REWARD_TYPE reward_type;
    public int reward_item;
    public int reward_count;
}