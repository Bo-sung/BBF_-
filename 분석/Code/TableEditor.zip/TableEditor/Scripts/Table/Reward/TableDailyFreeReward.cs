﻿using System.Collections;
using System.Collections.Generic;


public class TableDailyFreeReward
{
    public int index;
    public int reward_count;
}