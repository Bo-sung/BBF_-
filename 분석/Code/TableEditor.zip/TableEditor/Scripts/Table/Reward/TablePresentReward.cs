﻿using System.Collections;
using System.Collections.Generic;


public class TablePresentReward
{
    public int index;
    public REWARD_TYPE type;
    public int reward;
    public int count;
}