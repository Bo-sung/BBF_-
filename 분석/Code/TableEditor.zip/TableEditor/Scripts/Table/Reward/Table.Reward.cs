﻿using System.Collections;
using System.Collections.Generic;


public partial class Table
{
    public class Reward
    {
        [TableLoad(typeof(TablePresentReward[]), "presentReward")]
        public static TablePresentReward[] tablePresentRewards;

        [TableLoad(typeof(TableClearReward[]), "clearReward")]
        public static TableClearReward[] tableClearRewards;

        [TableLoad(typeof(TableRandomBox[]), "randomBox")]
        public static TableRandomBox[] tableRandomBoxes;

        [TableLoad(typeof(TableDailyFreeReward[]), "dailyFreeReward")]
        public static TableDailyFreeReward[] tableDailyFreeRewards;

        public static TablePresentReward GetRandomTablePresentReward()
        {
            return tablePresentRewards[0];
            //return tablePresentRewards[Random.Range(0, tablePresentRewards.Length)];
        }

        public static TableClearReward GetClearReward(int index)
        {
            return tableClearRewards[index];
        }
    }
}