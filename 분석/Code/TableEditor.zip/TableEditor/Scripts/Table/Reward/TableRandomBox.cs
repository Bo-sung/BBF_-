﻿using System.Collections;
using System.Collections.Generic;


public class TableRandomBox
{
    public int boxIndex;
    public REWARD_TYPE type;
    public int rewardIndex;
    public int count;
    public int probability;
}