﻿using System.Collections;
using System.Collections.Generic;


public partial class Table
{
    public class Item
    {
        [TableLoad(typeof(TableItem[]), "item")]
        public static TableItem[] tableItems;

        [TableLoad(typeof(TableShopItem[]), "shopItem")]
        public static TableShopItem[] tableShopItems;
    }
}