﻿using System.Collections;
using System.Collections.Generic;


public class TableItem
{
    public int index;
    public string name;
    public int count;
    public int price;
    public string explain;
}