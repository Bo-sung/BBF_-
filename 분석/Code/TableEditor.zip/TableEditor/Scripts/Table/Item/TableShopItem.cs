﻿using System.Collections;
using System.Collections.Generic;


public class TableShopItem
{
    public int index;
    public int item_index;
    public int item_count;
    public int require_gemstone;
    public int discount_rate;
}