﻿using System.Collections;
using System.Collections.Generic;


public class TableEvent
{
    public int index;
    /// <summary>
    /// 목표별 갯수
    /// </summary>
    public int star;
    /// <summary>
    /// 보상 갯수
    /// </summary>
    public int reward_count;
}