﻿using System.Collections;
using System.Collections.Generic;


public class TableEventReward
{
    public int index;
    public int inappIndex;
    public int multiple;
    public int reward;
}