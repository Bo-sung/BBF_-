﻿using System.Collections;
using System.Collections.Generic;


public partial class Table
{
    public class Event
    {
        [TableLoad(typeof(TableEvent[]), "event")]
        public static TableEvent[] tableEvents;

        [TableLoad(typeof(TableEventReward[]), "eventReward")]
        public static TableEventReward[] tableEventRewards;
    }
}