﻿using System.Collections;
using System.Collections.Generic;


public partial class Table
{
    public class CoinPig
    {
        [TableLoad(typeof(TableCoinPig[]), "piggybank")]
        public static TableCoinPig[] tableCoinPigs;
    }
}