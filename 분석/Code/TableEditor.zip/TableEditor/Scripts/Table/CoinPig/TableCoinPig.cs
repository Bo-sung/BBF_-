﻿using System.Collections;
using System.Collections.Generic;


public class TableCoinPig
{
    public int index;
    public int level;
    public int minCount;
    public int maxCount;
    public int bonus_percent;
}