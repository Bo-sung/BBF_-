﻿using System.Collections;
using System.Collections.Generic;


public class TableLevel
{
    public int lv;
    /// <summary>
    /// 일반 모드:0, 하드모드:1
    /// </summary>
    public int hard;
}