﻿using System.Collections;
using System.Collections.Generic;


public partial class Table
{
    public class Level
    {
        [TableLoad(typeof(TableLevel[]), "level")]
        public static TableLevel[] tableLevels;
    }
}