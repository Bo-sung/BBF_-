﻿using System.Collections;
using System.Collections.Generic;


public class TableGameBuff
{
    public int x;
    public int y;
    public BUFF_TYPE buff;
}