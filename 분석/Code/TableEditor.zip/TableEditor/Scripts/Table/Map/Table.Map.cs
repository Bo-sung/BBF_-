﻿using System.Collections;
using System.Collections.Generic;


public partial class Table
{
    public class Map
    {
        public static TableMap GetTableMap(int level)
        {
            string textAsset = Util.FileManager.GetJSON(string.Format("Table\\Output\\level_{0:D4}", level));
            return Util.JsonNewtonsoft.DeserializeObject<TableMap>(textAsset);
        }
    }
}