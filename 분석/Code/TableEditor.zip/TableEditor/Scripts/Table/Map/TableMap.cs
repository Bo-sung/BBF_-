﻿using System.Collections;
using System.Collections.Generic;


public class TableMap
{
    /// <summary>
    /// 레벨(1~)
    /// </summary>
    public int l;
    /// <summary>
    /// 맵의 높이
    /// </summary>
    public int h;
    /// <summary>
    /// 맵의 넓이
    /// </summary>
    public int w;
    /// <summary>
    /// 벽돌데이터
    /// </summary>
    public TableGameBrick[] br;
    /// <summary>
    /// 버프 데이터
    /// </summary>
    public TableGameBuff[] bu;
}