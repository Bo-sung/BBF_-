﻿using System.Collections;
using System.Collections.Generic;


public class TableGameBrick
{
    public int x;
    public int y;
    public int hp;
    /// <summary>
    /// 블럭 가로 길이
    /// </summary>
    public int w;
    /// <summary>
    /// 블럭 세로 길이
    /// </summary>
    public int h;
    /// <summary>
    /// 블럭 종류
    /// </summary>
    public BRICK_SHAPE t;
    /// <summary>
    /// 블럭 컬러
    /// </summary>
    public BRICK_COLOR_TYPE c;
    /// <summary>
    /// 블럭 회전
    /// </summary>
    public BRICK_ROTATION_TYPE r;
    /// <summary>
    /// 블럭 이벤트
    /// </summary>
    public BRICK_EVENT_TYPE e;
}