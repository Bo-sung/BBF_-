﻿using System.Collections;
using System.Collections.Generic;

using System;
using System.Reflection;

public partial class Table
{
    public static System.Action<string> OnLog;
    public static void LoadData()
    {
        var fieldInfos = typeof(Table).GetNestedTypes();
        for (int i = 0, count = fieldInfos.Length; i < count; i++)
        {
            var a = fieldInfos[i].Name;
            OnLog?.Invoke(string.Format("Table {0} Load Start\n", a));
            LoadData(fieldInfos[i]);
            OnLog?.Invoke(string.Format("Table {0} Load Finish\n", a));
        }
    }

    private static void LoadData(Type type)
    {
        FieldInfo[] fieldInfos = type.GetFields();
        for (int i = 0, count = fieldInfos.Length; i < count; i++)
        {
            TableLoad tableLoad = fieldInfos[i].GetCustomAttribute<TableLoad>();
            if (tableLoad != null)
            {
                object data = tableLoad.GetValue();
                fieldInfos[i].SetValue(type, data);
            }
        }
    }
}
