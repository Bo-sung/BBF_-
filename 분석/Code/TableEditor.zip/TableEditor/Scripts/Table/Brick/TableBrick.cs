﻿using System.Collections;
using System.Collections.Generic;


public class TableBrick
{
    public int index;
    public string name;
    public bool breachable;
    public bool movedown;
    public bool color_exchange;
    public bool rotation;
}