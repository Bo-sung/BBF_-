﻿using System.Collections;
using System.Collections.Generic;


public class TableBrickHpPosi
{
    public BRICK_SHAPE type;
    public BRICK_ROTATION_TYPE rotation;
    public float x;
    public float y;
}