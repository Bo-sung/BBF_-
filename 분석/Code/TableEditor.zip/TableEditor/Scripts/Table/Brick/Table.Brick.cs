﻿using System.Collections;
using System.Collections.Generic;


public partial class Table
{
    public class Brick
    {
        [TableLoad(typeof(TableBrick[]), "brick")]
        public static TableBrick[] tableBricks;

        [TableLoad(typeof(TableBrickShape[]), "brickShape")]
        public static TableBrickShape[] tableBrickShape;

        [TableLoad(typeof(TableBrickHpPosi[]), "brickHpPosi")]
        public static TableBrickHpPosi[] tableBrickHpPosi;
    }
}