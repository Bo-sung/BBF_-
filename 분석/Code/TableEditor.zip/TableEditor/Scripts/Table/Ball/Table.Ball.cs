﻿using System.Collections;
using System.Collections.Generic;


public partial class Table
{
    public class Ball
    {
        [TableLoad(typeof(TableBall[]), "ball")]
        public static TableBall[] tableBalls;
    }
}