﻿using System.Collections;
using System.Collections.Generic;


public class TableBall
{
    public int index;
    public int size;
    public int optionball_count;
    public int require_level;
    public int require_gemstone;
}