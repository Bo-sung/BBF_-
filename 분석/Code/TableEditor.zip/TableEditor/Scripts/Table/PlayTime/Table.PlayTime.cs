﻿using System.Collections;
using System.Collections.Generic;


public partial class Table
{
    public class PlayTime
    {
        [TableLoad(typeof(TablePlayTime[]), "playTime")]
        public static TablePlayTime[] tablePlayTimes;
    }
}