﻿using System.Collections;
using System.Collections.Generic;


public class TablePlayTime
{
    public int index;
    public int complete_time;
    public int reward;
}