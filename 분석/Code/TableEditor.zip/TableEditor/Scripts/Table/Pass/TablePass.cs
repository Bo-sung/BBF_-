﻿using System.Collections;
using System.Collections.Generic;


public class TablePass
{
    public int index;
    public int level;

    public REWARD_TYPE gold_reward;
    public int gold_index;
    public int gold_count;

    public REWARD_TYPE free_reward;
    public int free_index;
    public int free_count;
}