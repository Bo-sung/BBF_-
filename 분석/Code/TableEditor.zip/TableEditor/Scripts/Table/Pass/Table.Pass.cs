﻿using System.Collections;
using System.Collections.Generic;


public partial class Table
{
    public class Pass
    {
        [TableLoad(typeof(TablePass[]), "pass")]
        public static TablePass[] tablePasses;
    }
}