﻿using System.Collections;
using System.Collections.Generic;


public class TableAchievementGameService
{
    public int index;
    public string ios_id;
    public string aos_id;
    public int level;
}