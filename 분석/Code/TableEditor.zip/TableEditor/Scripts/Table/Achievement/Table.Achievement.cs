﻿using System.Collections;
using System.Collections.Generic;

public partial class Table
{
    public class Achievement
    {
        [TableLoad(typeof(TableAchievement[]), "achievement")]
        public static TableAchievement[] tableAchievements;

        [TableLoad(typeof(TableAchievementGameService[]), "achievement_gameservice")]
        public static TableAchievementGameService[] tableAchievementGameServices;
    }
}