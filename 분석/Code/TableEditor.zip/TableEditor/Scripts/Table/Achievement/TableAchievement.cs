﻿using System.Collections;
using System.Collections.Generic;


public class TableAchievement
{
    public int index;
    public ACHIEVEMENT_REPREAT_TYPE type;
    public int complete;
    public int reward;
    public string translate;
}