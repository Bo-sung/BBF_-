﻿using System.Collections;
using System.Collections.Generic;


public class TableFreeItem
{
    public int index;
    public int level;
    public ITEM_TYPE type;
    public int count;
}