﻿using System.Collections;
using System.Collections.Generic;


public partial class Table
{
    public class FreeItem
    {
        [TableLoad(typeof(TableFreeItem[]), "freeItem")]
        public static TableFreeItem[] tableFreeItems;
    }
}