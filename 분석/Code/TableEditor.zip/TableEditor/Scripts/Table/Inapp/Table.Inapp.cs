﻿using System.Collections;
using System.Collections.Generic;


public partial class Table
{
    public class Inapp
    {
        [TableLoad(typeof(TableInapp[]), "inapp")]
        public static TableInapp[] tableInapp;

        public static TableInapp GetTableInapp(INAPP_TYPE type)
        {
            for (int i = 0, count = tableInapp.Length; i < count; i++)
            {
                if (tableInapp[i].index == (int)type)
                {
                    return tableInapp[i];
                }
            }

            return null;
        }
    }
}