﻿using System.Collections;
using System.Collections.Generic;

public class TableInapp
{
    public int index;
    public GamebaseProductType type;
    public string name;
    public int gem;
    public string id;
    public int bonus_rate;

    public int item1;
    public int item1Count;

    public int item2;
    public int item2Count;

    public int item3;
    public int item3Count;

    public int item4;
    public int item4Count;
}