﻿public enum GAME_STATE
{
    NONE,
    INIT,
    FISRT_EFFECT,
    FIRST,
    SHOT,
    NEXT_ROUND,
    WAIT_EVENT,
    CHECK,
    READY,
    USE_ITEM,
    RETRY,
    DIE,
    CLEAR,
    Release,
}

public enum BRICK_SHAPE
{
    square,
    triangle,
    regular_triangle,
    diamond,
    circle,
    open_and_close,
    unbreakable,
    transparency,
    bomb,
}

public enum BRICK_ROTATION_TYPE
{
    ROTATION_0,
    ROTATION_90,
    ROTATION_180,
    ROTATION_270,
}

public enum BRICK_COLOR_TYPE
{
    blue,
    green,
    lightgreen,
    mint,
    orange,
    pink,
    purple,
    red,
    yellow,
    MAX,
}

public enum BRICK_EVENT_TYPE
{
    NONE = -1,
    bomb,
    bomb_left_right,
    bomb_up_down,
    bomb_4direction,
    missile,
    lightning,
    gift,
    gems,
    fix,
    laser,
    bomb_x,
}

public enum BUFF_TYPE
{
    NONE = -1,
    ADD_BALL_1,
    ADD_BALL_2,
    LASER_UPDOWN,
    LASER_LEFTRIGHT,
    LASER_CROSS,
    LASER_X,
    RANDOM_90,
    RANDOM_360,
    LASER_CIRCLE,
    MOVING_BAR,
    SPLASH_ENERGY,
    ADD_BALL_3,
    ADD_BALL_4,
    ADD_BALL_5,
}

public enum REWARD_TYPE
{
    ITEM,
    GEM,
    BALL,
}

public enum LEVEL_STATE
{
    CLOSE,
    OPEN,
    COMPLETE,
}

public enum LANGUAGE_TYPE
{
    EN,
    KO,
    JA,
    FR,
    RU,
    PT,
    DE,
    ES,
    TH,
    IT,
    ID,
    SC,
    TC,
    AR,
    MS,
    TR,
    MAX,
}

public enum INAPP_TYPE
{
    GEM_300,
    GEM_500,
    GEM_2000,
    GEM_5000,
    GEM_11000,
    GOLDEN_AIM,
    PACKAGE_STARTER,
    PACKAGE_PRO,
    PACKAGE_WEEK,
    PACKAGE_SIMPLE,
    PACKAGE_SPECIAL,
    PACKAGE_PREMIUM,
    PACKCAGE_CRAZY,
    COIN_PIG,
    REMOVE_ADS,
    PACKAGE_BALL,
    SUB_WEEK,
    SUB_MONTH,
    SUB_YEAR,
    PREMIUM_PASS,
    Test1200Single
}

public enum SHOP_TYPE
{
    GEM,
    PACKAGE,
    BALL,
    NONE,
}

public enum RANDOM_BOX_TYPE
{
    NONE,
    DAILY_FREE,
}

public enum ACHIEVEMENT_TYPE
{
    LEVEL_CLEAR,
    USE_ITEM,
    VISIT_SHOP,
    SHOW_ADS,
    USE_SPLASH,
    INAPP_PURCHASE
}

public enum ACHIEVEMENT_REPREAT_TYPE
{
    REPEAT,
    DAILY,
}

public enum REWARD_STATE
{
    WAIT,
    ENABLE_REWARD,
    COMPLETE,
}

public enum ITEM_TYPE
{
    REDUCE_HP,
    ADD_BALL,
    REMOVE_LASTLINE,
    REMOVE_VERTICAL,
}

public enum FREE_ITEM_STATE
{
    NOT_FREE,
    ENABLE_FREE,
    INFINITE_FREE,
}

public enum BALL_STATE
{
    CLOSE,
    OPEN,
    GET,
}

public enum SKILL_TYPE
{
    NONE = 0,
    RANGE_REDUCE,
    ADD_BALL,
    REMOVE_HORIZONAL,
    ENENRGY,
}

public enum GamebaseProductType
{
    UNKNOWN = 0,
    CONSUMABLE = 1,     //일회성
    AUTORENEWABLE = 2,  //구독
    CONSUMABLE_AUTO_RENEWABLE = 3,   //소비성 구독
    consumable = -1,            //레거시 일회성
    Subscription = -2,          //레거시 구독
    nonconsumable = -3,         //레거시 소비성 구독
}