﻿using System.Collections;
using System.Collections.Generic;

public class ConstData
{
    public const int levelCount = 1000;
    public const int baseBallCount = 50;

    public const float brickImgSize = 0.63f;
    public const float brickAreaSize = 0.64f;
    public const float blockGap = 0.65f;
    public const float twoStarScoreRate = 5f;
    public const float threeStarScoreRate = 10f;

    public const int adsGemCount = 50;
    /// <summary>
    /// 광고 제거 되는 레벨
    /// </summary>
    public const int removeAdsLevel = 300;

    /// <summary>
    /// 스플래시 게이지 최대 값
    /// </summary>
    public const int splashEnergyMaxCount = 5;

    public const float ballSmallRadius = 10f;
    public const float ballMediumRadius = 11f;
    public const float ballLargeRadius = 12f;

    public const string googleStoreGameURL = "market://details?id=com.superbox.aos.bbfriends";
    public const string googleStoreCompanyURL = "https://play.google.com/store/apps/dev?id=6831347196585294074";

    public const string appleStoreGameURL = "itms-apps://itunes.apple.com/app/id1602463147";
    public const string appleStoreCompanyURL = "https://itunes.apple.com/developer/id1165756567";

    public const string oneLinkStoreURL = "http://onelink.to/bbfriends";
}