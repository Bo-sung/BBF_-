﻿using System.Collections;
using System.Collections.Generic;
using System;
using Newtonsoft.Json;
public class TableLoad : Attribute
{
    public Type type;
    public string path;

    public TableLoad() { }
    public TableLoad(Type type, string path)
    {
        this.type = type;
        this.path = path;
    }

    public virtual object GetValue()
    {
        string strJson = Util.FileManager.GetJSON(string.Format("\\Table\\{0}{1}", path,".json"));
        return Util.JsonNewtonsoft.DeserializeObject(strJson, type);
    }
}

public partial class Util
{
    public class FileManager
    {
        private static string m_Directory_Path;

        public static void SetDirectory(string _dir)
        {
            m_Directory_Path = _dir;
        }

        public static string GetJSON(string _Path)
        {
            return GetJSON(_Path, out string a);
        }
        public static string GetJSON(string _Path, out string _err)
        {
            _err = "";
            return System.IO.File.ReadAllText(m_Directory_Path + _Path);
        }
    }
    public class JsonNewtonsoft
    {
        public static object DeserializeObject(string strJson)
        {
            return JsonConvert.DeserializeObject(strJson);
        }

        public static T DeserializeObject<T>(string strJson)
        {
            return JsonConvert.DeserializeObject<T>(strJson);
        }

        public static object DeserializeObject(string strJson, System.Type type)
        {
            return JsonConvert.DeserializeObject(strJson, type);
        }

        public static string SerializeObject(object value)
        {
            return JsonConvert.SerializeObject(value);
        }
    }
}